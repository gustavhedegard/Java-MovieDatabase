package movieDatabase;

/**
 * Class representing a movie and its information.
 * @author Gustav Selin
 */
public class Movie {
    public String Title;
    public String ReviewScore;
}
